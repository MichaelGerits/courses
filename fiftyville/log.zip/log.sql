-- Keep a log of any SQL queries you execute as you solve the mystery.

--gets the right crime (crime_scene_reports):
    SELECT description, id FROM crime_scene_reports WHERE year = 2021 AND month = 7 AND day = 28 AND street = "Humphrey Street";
    --(time: 10:15AM)(location: bakery)(3 witnesses)(all mention bakery)(id: 295)

-- get the witnesses of the crime (interviews):
    SELECT name, id, transcript FROM interviews WHERE year = 2021 AND month = 7 AND transcript LIKE "%bakery%";
    --(Ruth)(161):within 10 min of crime thief left --> look at bakery_security_log
    --(Eugene)(162):RECOGNISED FROM ATM(withdrawing) "Leggett Street" --> look at atm_transactions
    --(Raymond)(163): call(<1 min),earliest flight next day, other person buy ticket --> look at flights

--go through each witness report:
    --check the bakery security logs at that time (bakery_security_logs):
        SELECT license_plate, id FROM bakery_security_logs WHERE year = 2021 AND month = 7 AND day = 28 AND hour = 10
        AND (minute < 25 AND minute > 15) AND activity = "exit";
        --given list of possibilities liscence plates

    --go through (atm_transactions):
        SELECT account_number, amount, id FROM atm_transactions WHERE year = 2021 AND month = 7 AND day = 28 AND atm_location = "Leggett Street" AND transaction_type = "withdraw";
        SELECT person_id, amount FROM bank_accounts AS ba JOIN atm_transactions AS atm ON ba.account_number = atm.account_number WHERE atm.year = 2021 AND atm.month = 7 AND atm.day = 28 AND atm.atm_location = "Leggett Street" AND atm.transaction_type = "withdraw";
        --given list of possibilities accounts/people

    --go through (phone_calls):
        SELECT caller, receiver, duration, id FROM phone_calls WHERE year = 2021 AND month = 7 AND day = 28 AND duration < 60;
        --given list of possible people

    --search the earliest flight the next day(flights):
        SELECT f.id, city, full_name, abbreviation, hour, minute FROM airports AS a JOIN flights AS f ON f.destination_airport_id = a.id
            WHERE f.year = 2021 AND f.month = 7 AND f.day = 29 AND f.origin_airport_id = (SELECT id FROM airports WHERE city = "Fiftyville") ORDER BY hour, minute ASC;
        --five diffrent flights that next day (earliest to "New York City", "LGA", 8:20, flight_id = 36)

--get thief by combining these lists (people):
    SELECT name, phone_number, id FROM people
        WHERE id IN (SELECT person_id FROM bank_accounts AS ba JOIN atm_transactions AS atm ON ba.account_number = atm.account_number WHERE atm.year = 2021 AND atm.month = 7 AND atm.day = 28 AND atm.atm_location = "Leggett Street" AND atm.transaction_type = "withdraw")
        AND license_plate IN (SELECT license_plate FROM bakery_security_logs WHERE year = 2021 AND month = 7 AND day = 28 AND hour = 10 AND (minute < 25 AND minute > 15) AND activity = "exit")
        AND phone_number IN (SELECT caller FROM phone_calls WHERE year = 2021 AND month = 7 AND day = 28 AND duration < 60)
        AND passport_number IN (SELECT passport_number FROM passengers WHERE flight_id = 36);
    --Bruce((367) 555-5533)(686048)

--get the culprit that Bruce called with:
    SELECT p.id, p.name, pc.caller FROM people AS p JOIN phone_calls AS pc ON p.phone_number = pc.receiver WHERE pc.year = 2021 AND pc.month = 7 AND pc.day = 28 AND pc.duration < 60 AND pc.caller = (SELECT phone_number FROM people WHERE id = 686048);
    --Robin(864400)